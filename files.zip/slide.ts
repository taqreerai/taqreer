import { z } from "zod";

// ─── Primitives ───────────────────────────────────────────────────────────────

const HexColor = z
  .string()
  .regex(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/, "Must be a hex color e.g. #FF0000");

const FontWeight = z.union([
  z.literal(100), z.literal(200), z.literal(300), z.literal(400),
  z.literal(500), z.literal(600), z.literal(700), z.literal(800), z.literal(900),
]);

const TextAlign = z.enum(["left", "right", "center"]);
const Direction = z.enum(["ltr", "rtl"]);

// ─── Gradient ─────────────────────────────────────────────────────────────────

const LinearGradient = z.object({
  type: z.literal("linear"),
  angle: z.number().min(0).max(360),
  stops: z.tuple([
    z.object({ color: HexColor, position: z.number().min(0).max(100) }),
    z.object({ color: HexColor, position: z.number().min(0).max(100) }),
  ]),
});

const SolidBackground = z.object({
  type: z.literal("color"),
  value: HexColor,
});

const GradientBackground = z.object({
  type: z.literal("gradient"),
  gradient: LinearGradient,
});

const Background = z.discriminatedUnion("type", [SolidBackground, GradientBackground]);

// ─── Shadow ───────────────────────────────────────────────────────────────────

const Shadow = z.object({
  color: HexColor,
  blur: z.number().min(0).max(50),
  offsetX: z.number(),
  offsetY: z.number(),
});

// ─── Border ───────────────────────────────────────────────────────────────────

const Border = z.object({
  color: HexColor,
  width: z.number().min(0).max(20),
  style: z.enum(["solid", "dashed", "dotted"]),
  radius: z.number().min(0).max(100).optional(),
});

// ─── Elements ─────────────────────────────────────────────────────────────────

const BaseElement = z.object({
  id: z.string().min(1),
  x: z.number(),
  y: z.number(),
  width: z.number().positive(),
  height: z.number().positive(),
  rotation: z.number().min(-360).max(360).optional().default(0),
  opacity: z.number().min(0).max(1).optional().default(1),
  shadow: Shadow.optional(),
  border: Border.optional(),
});

const TextElement = BaseElement.extend({
  type: z.literal("text"),
  role: z.enum(["headline", "subheading", "body", "caption", "label"]).optional(),
  content: z.string(),
  fontFamily: z.string(),
  fontSize: z.number().min(6).max(300),
  fontWeight: FontWeight.optional().default(400),
  color: HexColor,
  textAlign: TextAlign,
  direction: Direction,
  lineHeight: z.number().min(1).max(3).optional().default(1.5),
  italic: z.boolean().optional().default(false),
  underline: z.boolean().optional().default(false),
  background: HexColor.optional(),
});

const ImageElement = BaseElement.extend({
  type: z.literal("image"),
  role: z.enum(["logo", "hero", "icon", "decoration"]).optional(),
  src: z.string().url(),
  objectFit: z.enum(["contain", "cover", "fill"]).optional().default("contain"),
});

const ShapeElement = BaseElement.extend({
  type: z.literal("shape"),
  role: z.enum(["background", "accent", "divider", "decoration"]).optional(),
  kind: z.enum(["rectangle", "circle", "ellipse", "triangle", "line"]),
  fill: z.union([SolidBackground, GradientBackground]).optional(),
});

const SlideElement = z.discriminatedUnion("type", [
  TextElement,
  ImageElement,
  ShapeElement,
]);

// ─── Slide ────────────────────────────────────────────────────────────────────

const Slide = z.object({
  slideId: z.string().min(1),
  role: z.enum(["cover", "agenda", "content", "stats", "quote", "image", "closing"]).optional(),
  background: Background,
  elements: z.array(SlideElement),
});

// ─── Fonts ────────────────────────────────────────────────────────────────────

const FontDefinition = z.object({
  name: z.string(),
  url: z.string().url(),
});

// ─── Palette ──────────────────────────────────────────────────────────────────

const Palette = z.object({
  primary: HexColor,
  secondary: HexColor,
  background: HexColor,
  text: HexColor,
  muted: HexColor,
});

// ─── Root Manifest ────────────────────────────────────────────────────────────

export const SlideManifestSchema = z.object({
  version: z.literal("1.0"),
  presentationId: z.string().min(1),
  language: z.enum(["ar", "en"]),
  direction: Direction,
  canvas: z.object({
    width: z.literal(1920),
    height: z.literal(1080),
  }),
  fonts: z.object({
    heading: FontDefinition,
    body: FontDefinition,
  }),
  palette: Palette,
  slides: z.array(Slide).min(1),
});

export type SlideManifest = z.infer<typeof SlideManifestSchema>;
export type SlideType = z.infer<typeof Slide>;
export type SlideElementType = z.infer<typeof SlideElement>;
export type TextElementType = z.infer<typeof TextElement>;
export type ImageElementType = z.infer<typeof ImageElement>;
export type ShapeElementType = z.infer<typeof ShapeElement>;
